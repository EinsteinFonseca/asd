﻿namespace Atividade___Fornecedor
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            txtNumero = new TextBox();
            txtSala = new TextBox();
            txtEndereco = new TextBox();
            txtSetor = new TextBox();
            txtxFuncao = new TextBox();
            label5 = new Label();
            label4 = new Label();
            txtRG = new TextBox();
            textBox1 = new TextBox();
            label3 = new Label();
            txtCPF = new TextBox();
            label2 = new Label();
            label1 = new Label();
            txtNome = new TextBox();
            btSalvar = new Button();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.Location = new Point(383, 82);
            panel1.Name = "panel1";
            panel1.Size = new Size(10, 334);
            panel1.TabIndex = 63;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Consolas", 15.75F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            label10.Location = new Point(241, 34);
            label10.Name = "label10";
            label10.Size = new Size(262, 24);
            label10.TabIndex = 62;
            label10.Text = "CADASTRAR FUNCIONÁRIO";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Consolas", 12F, FontStyle.Bold);
            label9.Location = new Point(102, 339);
            label9.Name = "label9";
            label9.Size = new Size(81, 19);
            label9.TabIndex = 61;
            label9.Text = "Endereço";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Consolas", 12F, FontStyle.Bold);
            label8.Location = new Point(100, 271);
            label8.Name = "label8";
            label8.Size = new Size(171, 19);
            label8.TabIndex = 60;
            label8.Text = "Numero de tefolene";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Consolas", 12F, FontStyle.Bold);
            label7.Location = new Point(438, 212);
            label7.Name = "label7";
            label7.Size = new Size(54, 19);
            label7.TabIndex = 59;
            label7.Text = "Setor";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Consolas", 12F, FontStyle.Bold);
            label6.Location = new Point(438, 265);
            label6.Name = "label6";
            label6.Size = new Size(45, 19);
            label6.TabIndex = 58;
            label6.Text = "Sala";
            // 
            // txtNumero
            // 
            txtNumero.BackColor = SystemColors.HotTrack;
            txtNumero.Font = new Font("Consolas", 12F, FontStyle.Bold);
            txtNumero.Location = new Point(102, 293);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(238, 26);
            txtNumero.TabIndex = 57;
            // 
            // txtSala
            // 
            txtSala.BackColor = SystemColors.HotTrack;
            txtSala.Font = new Font("Consolas", 12F, FontStyle.Bold);
            txtSala.Location = new Point(436, 293);
            txtSala.Name = "txtSala";
            txtSala.Size = new Size(198, 26);
            txtSala.TabIndex = 56;
            // 
            // txtEndereco
            // 
            txtEndereco.BackColor = SystemColors.HotTrack;
            txtEndereco.Font = new Font("Consolas", 12F, FontStyle.Bold);
            txtEndereco.Location = new Point(102, 361);
            txtEndereco.Name = "txtEndereco";
            txtEndereco.Size = new Size(238, 26);
            txtEndereco.TabIndex = 55;
            // 
            // txtSetor
            // 
            txtSetor.BackColor = SystemColors.HotTrack;
            txtSetor.Font = new Font("Consolas", 12F, FontStyle.Bold);
            txtSetor.Location = new Point(437, 230);
            txtSetor.Name = "txtSetor";
            txtSetor.Size = new Size(197, 26);
            txtSetor.TabIndex = 54;
            // 
            // txtxFuncao
            // 
            txtxFuncao.BackColor = SystemColors.HotTrack;
            txtxFuncao.Font = new Font("Consolas", 12F, FontStyle.Bold);
            txtxFuncao.Location = new Point(436, 174);
            txtxFuncao.Name = "txtxFuncao";
            txtxFuncao.Size = new Size(200, 26);
            txtxFuncao.TabIndex = 53;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Consolas", 12F, FontStyle.Bold);
            label5.Location = new Point(437, 146);
            label5.Name = "label5";
            label5.Size = new Size(63, 19);
            label5.TabIndex = 52;
            label5.Text = "Função";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Consolas", 12F, FontStyle.Bold);
            label4.Location = new Point(437, 78);
            label4.Name = "label4";
            label4.Size = new Size(27, 19);
            label4.TabIndex = 51;
            label4.Text = "RG";
            // 
            // txtRG
            // 
            txtRG.BackColor = SystemColors.HotTrack;
            txtRG.Font = new Font("Consolas", 12F, FontStyle.Bold);
            txtRG.Location = new Point(437, 96);
            txtRG.Name = "txtRG";
            txtRG.Size = new Size(199, 26);
            txtRG.TabIndex = 50;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.HotTrack;
            textBox1.Font = new Font("Consolas", 12F, FontStyle.Bold);
            textBox1.Location = new Point(100, 230);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(240, 26);
            textBox1.TabIndex = 49;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Consolas", 12F, FontStyle.Bold);
            label3.Location = new Point(100, 208);
            label3.Name = "label3";
            label3.Size = new Size(45, 19);
            label3.TabIndex = 48;
            label3.Text = "CTPS";
            // 
            // txtCPF
            // 
            txtCPF.BackColor = SystemColors.HotTrack;
            txtCPF.Font = new Font("Consolas", 12F, FontStyle.Bold);
            txtCPF.Location = new Point(100, 168);
            txtCPF.Name = "txtCPF";
            txtCPF.Size = new Size(240, 26);
            txtCPF.TabIndex = 47;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Consolas", 12F, FontStyle.Bold);
            label2.Location = new Point(102, 146);
            label2.Name = "label2";
            label2.Size = new Size(36, 19);
            label2.TabIndex = 46;
            label2.Text = "CPF";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Consolas", 12F, FontStyle.Bold);
            label1.Location = new Point(100, 74);
            label1.Name = "label1";
            label1.Size = new Size(45, 19);
            label1.TabIndex = 45;
            label1.Text = "Nome";
            // 
            // txtNome
            // 
            txtNome.BackColor = SystemColors.HotTrack;
            txtNome.Font = new Font("Consolas", 12F, FontStyle.Bold);
            txtNome.Location = new Point(100, 96);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(240, 26);
            txtNome.TabIndex = 44;
            // 
            // btSalvar
            // 
            btSalvar.BackColor = Color.CornflowerBlue;
            btSalvar.Font = new Font("Consolas", 12F, FontStyle.Bold);
            btSalvar.Location = new Point(436, 342);
            btSalvar.Name = "btSalvar";
            btSalvar.Size = new Size(198, 70);
            btSalvar.TabIndex = 43;
            btSalvar.Text = "Salvastes";
            btSalvar.UseVisualStyleBackColor = false;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SteelBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(txtNumero);
            Controls.Add(txtSala);
            Controls.Add(txtEndereco);
            Controls.Add(txtSetor);
            Controls.Add(txtxFuncao);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(txtRG);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(txtCPF);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtNome);
            Controls.Add(btSalvar);
            Name = "Menu";
            Text = "Menu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private TextBox txtNumero;
        private TextBox txtSala;
        private TextBox txtEndereco;
        private TextBox txtSetor;
        private TextBox txtxFuncao;
        private Label label5;
        private Label label4;
        private TextBox txtRG;
        private TextBox textBox1;
        private Label label3;
        private TextBox txtCPF;
        private Label label2;
        private Label label1;
        private TextBox txtNome;
        private Button btSalvar;
    }
}