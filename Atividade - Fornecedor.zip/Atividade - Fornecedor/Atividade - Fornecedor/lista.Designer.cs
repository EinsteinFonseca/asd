﻿namespace Atividade___Fornecedor
{
    partial class lista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label11 = new Label();
            label1 = new Label();
            dtLista = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dtLista).BeginInit();
            SuspendLayout();
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Consolas", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.Location = new Point(161, 417);
            label11.Name = "label11";
            label11.Size = new Size(0, 19);
            label11.TabIndex = 43;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Consolas", 14.25F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            label1.Location = new Point(280, 29);
            label1.Name = "label1";
            label1.Size = new Size(220, 22);
            label1.TabIndex = 44;
            label1.Text = "Lista de funcionários";
            // 
            // dtLista
            // 
            dtLista.BackgroundColor = Color.SlateGray;
            dtLista.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtLista.GridColor = SystemColors.ActiveCaptionText;
            dtLista.Location = new Point(12, 85);
            dtLista.Name = "dtLista";
            dtLista.Size = new Size(776, 353);
            dtLista.TabIndex = 45;
            // 
            // lista
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SteelBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(dtLista);
            Controls.Add(label1);
            Controls.Add(label11);
            Name = "lista";
            Text = "lista";
            ((System.ComponentModel.ISupportInitialize)dtLista).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label11;
        private Label label1;
        private DataGridView dtLista;
    }
}