﻿namespace Atividade___Fornecedor
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel3 = new Panel();
            panel2 = new Panel();
            panel1 = new Panel();
            label3 = new Label();
            label2 = new Label();
            button2 = new Button();
            btCadastrar = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = Color.LightSteelBlue;
            panel3.Location = new Point(1, 58);
            panel3.Name = "panel3";
            panel3.Size = new Size(803, 11);
            panel3.TabIndex = 12;
            // 
            // panel2
            // 
            panel2.BackColor = Color.RoyalBlue;
            panel2.Location = new Point(1, 36);
            panel2.Name = "panel2";
            panel2.Size = new Size(803, 24);
            panel2.TabIndex = 11;
            // 
            // panel1
            // 
            panel1.BackColor = Color.MidnightBlue;
            panel1.Controls.Add(label3);
            panel1.Location = new Point(1, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(803, 35);
            panel1.TabIndex = 10;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Consolas", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlLightLight;
            label3.Location = new Point(237, 11);
            label3.Name = "label3";
            label3.Size = new Size(286, 24);
            label3.TabIndex = 8;
            label3.Text = "Cadastro de Fucionários";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Consolas", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(111, 413);
            label2.Name = "label2";
            label2.Size = new Size(572, 22);
            label2.TabIndex = 9;
            label2.Text = "Aluno: Einstein Guimarães da Fonseca (〃￣︶￣)人(￣︶￣〃)";
            // 
            // button2
            // 
            button2.BackColor = Color.CornflowerBlue;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.DarkBlue;
            button2.Location = new Point(297, 251);
            button2.Name = "button2";
            button2.Size = new Size(164, 81);
            button2.TabIndex = 8;
            button2.Text = "LISTAR FUNCIONÁRIOS\r\n☝️(ﾟヮﾟ )";
            button2.UseVisualStyleBackColor = false;
            // 
            // btCadastrar
            // 
            btCadastrar.BackColor = Color.CornflowerBlue;
            btCadastrar.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCadastrar.ForeColor = Color.DarkBlue;
            btCadastrar.Location = new Point(297, 115);
            btCadastrar.Name = "btCadastrar";
            btCadastrar.Size = new Size(164, 81);
            btCadastrar.TabIndex = 7;
            btCadastrar.Text = " o(￣▽￣)ｄ\r\nCADASTRAR FUNCIONÁRIO";
            btCadastrar.UseVisualStyleBackColor = false;
            btCadastrar.Click += btCadastrar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SteelBlue;
            ClientSize = new Size(800, 450);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(btCadastrar);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel3;
        private Panel panel2;
        private Panel panel1;
        private Label label3;
        private Label label2;
        private Button button2;
        private Button btCadastrar;
    }
}
